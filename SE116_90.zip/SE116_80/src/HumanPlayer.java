import java.util.InputMismatchException;
import java.util.List;
import java.util.Scanner;

public class HumanPlayer extends Player{
    @Override
    public void Move(List<PointRule> board,List<PointRule> deck, List<PointRule> gameDeck) {
        System.out.println("Cards on the board: \n");
        for(PointRule boardCard : board){
            if(board.size()!=0) {
                System.out.println(Character.toString(boardCard.getSuit()) + Character.toString(boardCard.getRank()));
            }else{
                continue;
            }
        }
        System.out.println("");
        System.out.println("Your Cards:");
        int cardNumber = 0;
        for (PointRule deckCard : deck){
            System.out.println(cardNumber + "- " + Character.toString(deckCard.getSuit()) + Character.toString(deckCard.getRank()));
            cardNumber++;
        }
        Scanner pSc = new Scanner(System.in);
        int choice = -1;
        boolean validInput = false;
        while (!validInput) {
            try {
                System.out.println("Please enter number of the card that you want to pick: ");
                choice = pSc.nextInt();
                if (choice < 0 || choice >= deck.size()) {
                    throw new InputMismatchException();
                }
                validInput = true;
            } catch (InputMismatchException e) {
                System.out.println("Wrong input.");
                pSc.nextLine();
            }
        }

        PointRule card = deck.get(choice);//Player's Card

        if (board.size() == 0) {
            board.add(card);
            deck.remove(card);
        } else if ((board.size() == 1 && board.get(board.size() - 1).getRank() == card.getRank())) {
            PointRule.takeCardMisti(board, pMisti);
            pMisti.add(card);
            totalPoint += Calculator.calculateMisti(pMisti);
            Game.latestPlayer = this;
            deck.remove(card);
        } else if (board.get(board.size() - 1).getRank() == card.getRank() || card.getRank() == 'J') {
            PointRule.takeCardNormal(board, pNormal);
            pNormal.add(card);
            totalPoint += Calculator.calculateNormal(pNormal);
            Game.latestPlayer = this;
            deck.remove(card);
        } else {
            board.add(card);
            deck.remove(card);
        }
    }

}
