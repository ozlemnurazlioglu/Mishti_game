import java.lang.reflect.Array;
import java.util.ArrayList;
import java.util.List;

public class Game {

    private HumanPlayer player;
    private List<Player> bots;
    public static Player latestPlayer = null;



    private static final int EASY_BOT_DIFF = 1;
    private static final int MID_BOT_DIFF = 2;
    private static final int HARD_BOT_DIFF = 3;



    public Game(int playerCount, ArrayList<String> playerNames, ArrayList<Integer> difficulties) {
        player = new HumanPlayer();
        bots = new ArrayList<>();

        for (int i = 0; i < playerCount - 1; i++) {

            switch (difficulties.get(i)){
                case EASY_BOT_DIFF -> bots.add(new EzBot());
                case MID_BOT_DIFF -> bots.add(new MidBot());
                case HARD_BOT_DIFF -> bots.add(new HardBot());
            }
        }

        player.setName(playerNames.get(0));

        for (int i = 1; i < playerNames.size(); i++) {
            bots.get(i - 1).setName(playerNames.get(i));
        }

    }

    public void Play(List<PointRule> gameDeck, List<PointRule> Board)
    {
        int turnCount = 0;
        if(bots.size() == 3 && player != null){
            turnCount = 3;
        } else if(bots.size() == 2 && player != null){
            turnCount = 4;
        } else if(bots.size() == 1 && player != null){
            turnCount = 6;
        }

        int i = 0;


        // Bir tur
        while (i < turnCount){

            /**
             * Dealing hands for every player
             */
            PointRule.dealHand(gameDeck,player.getpDeck());
            for (Player bot: bots) {
                PointRule.dealHand(gameDeck, bot.getpDeck());
            }

            /**
             * Gameplay
             */
            for (int j = 0; j < 4; j++) {

                player.Move(Board, player.getpDeck(), gameDeck);

                for (Player bot: bots) {
                    bot.Move(Board, player.getpDeck(), gameDeck);
                }

            }

            i++;
        }

        latestPlayer.totalPoint += Calculator.calculateNormal(Board);

        int playerTotalPoint = player.totalPoint;
        ArrayList<Integer> botsTotalPoints = new ArrayList<>();
        for (int j = 0; j < bots.size(); j++) {
            botsTotalPoints.add(bots.get(i).totalPoint);
        }



    }







}
