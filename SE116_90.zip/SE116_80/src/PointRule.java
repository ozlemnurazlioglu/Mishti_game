import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Random;

public class PointRule extends Card {
    private char suit;
    private char rank;
    private int points;
    private List<PointRule> deckPlayable;

    public PointRule(char suit, char rank, int points) {
        super();
        this.suit = suit;
        this.rank = rank;
        this.points = points;
    }

    public PointRule() {
    }

    public char getSuit() {
        return suit;
    }

    public char getRank() {
        return rank;
    }

    public int getPoints() {
        return points;
    }

    public List<PointRule> getCards() {
        return deckPlayable;
    }

    public static void shuffle(List<PointRule> deck) {
        Collections.shuffle(deck);
    }

    public static void cutExtended(List<PointRule> deck) {
        Random random = new Random();
        int cutPoint = random.nextInt(deck.size());

        List<PointRule> firstPart = new ArrayList<>(deck.subList(0, cutPoint));
        List<PointRule> secondPart = new ArrayList<>(deck.subList(cutPoint, deck.size()));
        deck.clear();
        deck.addAll(secondPart);
        deck.addAll(firstPart);
    }

    public static void dealBoard(List<PointRule> deck, List<PointRule> board) {
        List<PointRule> boardTemp = new ArrayList<>(deck.subList(deck.size() - 4, deck.size()));
        board.addAll(boardTemp);
    }

    public static void dealHand(List<PointRule> deckPlayable, List<PointRule> hand) {
        List<PointRule> playableTemp = new ArrayList<>(deckPlayable.subList(deckPlayable.size() - 4, deckPlayable.size()));
        deckPlayable.subList(deckPlayable.size() - 4, deckPlayable.size()).clear();
        hand.addAll(playableTemp);
    }

    public static void takeCardNormal(List<PointRule> board, List<PointRule> takeNormal) {
            takeNormal.addAll(board);
            board.clear();
        }
        public static void takeCardMisti (List < PointRule > board, List < PointRule > takeMisti){
            takeMisti.addAll(board);
            board.clear();
        }

    }
