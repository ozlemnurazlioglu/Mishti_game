public class Card {
    private char suit;
    private char rank;
    private int points;

    public Card(char suit, char rank, int points) {
        this.suit = suit;
        this.rank = rank;
        this.points = points;
    }

    public Card() {

    }

    public char getSuit() {
        return suit;
    }

    public char getRank() {
        return rank;
    }

    public int getPoints() {
        return points;
    }
}