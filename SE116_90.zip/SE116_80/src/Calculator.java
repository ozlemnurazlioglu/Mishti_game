import java.util.List;

public class Calculator {
    public static int calculateNormal(List<PointRule> takenNormal) {
        int totalPoints = 0;
        for (PointRule card : takenNormal) {
            totalPoints += card.getPoints();
        }
        takenNormal.clear();
        return totalPoints;
    }
    public static int calculateMisti(List<PointRule> takenMisti){
        int totalPoints = 0;
        for(PointRule card :takenMisti){
            totalPoints +=(5*card.getPoints());
        }
        takenMisti.clear();
        return totalPoints;
    }
}
