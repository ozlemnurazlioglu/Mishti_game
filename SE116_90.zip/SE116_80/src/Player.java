import java.util.ArrayList;
import java.util.InputMismatchException;
import java.util.List;
import java.util.Scanner;

public abstract class Player implements PlayerMoves {

    int totalPoint = 0;
    public String name = "";
    protected List<PointRule> pDeck = new ArrayList<>();
    protected List<PointRule> pNormal = new ArrayList<>();
    protected List<PointRule> pMisti = new ArrayList<>();

    private String experience;


    public int getTotalPoint(){return totalPoint;}
    public List<PointRule> getpDeck(){return pDeck;}

    public void setName(String name) {
        this.name = name;
    }

    @Override
    public abstract void Move(List<PointRule> board, List<PointRule> deck, List<PointRule> gameDeck);
}

