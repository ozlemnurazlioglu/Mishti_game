import java.util.ArrayList;
import java.util.List;

public class HardBot extends Player {
    int index = 0;

    public PointRule bestCardToPick(List<PointRule> gameDeck, List<PointRule> deck) {
        List<Character> threeLeft = new ArrayList<>();//There are cards which were never dealt before in it so, multiplying size of this List by 3 isn't accurate
        List<Character> twoLeft = new ArrayList<>();
        List<Character> oneLeft = new ArrayList<>();

        for (PointRule card : gameDeck) {
            if (!threeLeft.contains(card.getRank()) && !twoLeft.contains(card.getRank()) && !oneLeft.contains(card.getRank())) {
                int count = 0;
                for (PointRule otherCard : gameDeck) {
                    if (card.getRank() == otherCard.getRank()) {
                        count++;
                    }
                }
                if (count >= 3) {
                    threeLeft.add(card.getRank());
                } else if (count == 2) {
                    twoLeft.add(card.getRank());
                } else if (count == 1) {
                    oneLeft.add(card.getRank());
                }
            }
        }
        //Checks if the bot has any cards with the same rank in threeLeft (includes never dealt cards too), twoLeft, and oneLeft
        for (Character rank : threeLeft) {
            for (PointRule card : deck) {
                if (card.getRank() == rank) {
                    return card;
                }
            }
        }
        for (Character rank : twoLeft) {
            for (PointRule card : deck) {
                if (card.getRank() == rank) {
                    return card;
                }
            }
        }
        for (Character rank : oneLeft) {
            for (PointRule card : deck) {
                if (card.getRank() == rank) {
                    return card;
                }
            }
        }

        //If the bot doesn't have any card with the same rank, plays the first card in its deck
        return deck.get(0);

    }

    @Override
    public void Move(List<PointRule> board, List<PointRule> deck, List<PointRule> gameDeck) {

        PointRule card = deck.get(index);//Bot's Card
        if (board.size() == 0) {
            card = bestCardToPick(gameDeck, deck);
            board.add(card);
            deck.remove(card);
        } else {
            PointRule lastCard = board.get(index);//Top Card on board

            for (int index = 0; index < deck.size(); index++) {
                if (card.getRank() == lastCard.getRank()) {
                    card = deck.get(index);//choose card
                } else if (card.getRank() == 'J') {
                    card = deck.get(index);
                } else {
                    card = bestCardToPick(gameDeck, deck);
                }
            }


            if (board.size() == 0) {
                board.add(card);
                deck.remove(card);
            } else if ((board.size() == 1 && board.get(board.size() - 1).getRank() == card.getRank())) {
                PointRule.takeCardMisti(board, pMisti);
                pMisti.add(card);
                totalPoint += Calculator.calculateMisti(pMisti);
                Game.latestPlayer = this;
                deck.remove(card);
            } else if (board.get(board.size() - 1).getRank() == card.getRank() || card.getRank() == 'J') {
                PointRule.takeCardNormal(board, pNormal);
                pNormal.add(card);
                totalPoint += Calculator.calculateNormal(pNormal);
                Game.latestPlayer = this;
                deck.remove(card);
            } else {
                board.add(card);
                deck.remove(card);
            }
        }
    }

}
