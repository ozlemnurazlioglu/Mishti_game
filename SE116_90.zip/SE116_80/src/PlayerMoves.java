import java.util.List;

public interface PlayerMoves{
    void Move(List<PointRule> board, List<PointRule> deck, List<PointRule> gameDeck);
}
