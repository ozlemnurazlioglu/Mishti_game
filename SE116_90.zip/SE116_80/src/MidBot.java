import java.util.ArrayList;
import java.util.List;

public class MidBot extends Player {
    int index = 0;

    @Override
    public void Move(List<PointRule> board,List<PointRule> deck, List<PointRule> gameDeck) {

        PointRule card = deck.get(index);//Bot's Card
        if (board.size() == 0) {
            board.add(card);
            deck.remove(card);
        } else {

            PointRule lastCard = board.get(index);//Top Card on board

            for (int index = 0; index < deck.size(); index++) {
                if (card.getRank() == lastCard.getRank()) {
                    card = deck.get(index);//choose card
                } else if (card.getRank() == 'J') {
                    card = deck.get(index);
                } else {
                    card = deck.get(index);
                }
            }

            if (board.size() == 0) {
                board.add(card);
                deck.remove(card);
            } else if ((board.size() == 1 && board.get(board.size() - 1).getRank() == card.getRank())) {
                PointRule.takeCardMisti(board, pMisti);
                pMisti.add(card);
                totalPoint += Calculator.calculateMisti(pMisti);
                Game.latestPlayer = this;
                deck.remove(card);
            } else if (board.get(board.size() - 1).getRank() == card.getRank() || card.getRank() == 'J') {
                PointRule.takeCardNormal(board, pNormal);
                pNormal.add(card);
                totalPoint += Calculator.calculateNormal(pNormal);
                Game.latestPlayer = this;
                deck.remove(card);
            } else {
                board.add(card);
                deck.remove(card);
            }
        }
    }

}
