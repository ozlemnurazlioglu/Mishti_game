import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.List;

public class PointRuleReader {
    public static List<PointRule> readPointRules(String fileName) {
        List<PointRule> pointRules = new ArrayList<>();

        try (InputStream is = PointRuleReader.class.getResourceAsStream(fileName);
             InputStreamReader isr = new InputStreamReader(is);
             BufferedReader br = new BufferedReader(isr)) {

            String line;
            while ((line = br.readLine()) != null) {
                char suit = line.charAt(0);
                char rank = line.charAt(1);
                int points = Integer.parseInt(line.substring(2).trim());
                pointRules.add(new PointRule(suit, rank, points));
            }
        } catch (IOException e) {
            e.printStackTrace();
        }

        return pointRules;
    }
}