import java.awt.*;
import java.util.*;
import java.util.List;
//4 Player -> 3 Rounds
//3 Player -> 4 Rounds
//2 Player -> 6 Rounds

public class Main {

    public static void main(String[] args) {
        List<PointRule> Board = new ArrayList<>();
        List<PointRule> PDeck = new ArrayList<>();
        List<PointRule> B2Deck = new ArrayList<>();
        List<PointRule> B3Deck = new ArrayList<>();
        Scanner sc = new Scanner(System.in);
        String pointRulesFile;
        System.out.println("Enter points rule directory:\n" + "Directory: /point_rules.txt");

        pointRulesFile = sc.nextLine();

        List<PointRule> pulledCards = PointRuleReader.readPointRules(pointRulesFile); //Read values
        PointRule.shuffle(pulledCards); //Shuffled values
        PointRule.cutExtended(pulledCards); //Cut values
        PointRule.dealBoard(pulledCards, Board); //Copy from pointRules list to Board list
        /*System.out.println("Before pRules");
        for (PointRule x : pointRules) {
            System.out.println(String.valueOf(x.getSuit()) + String.valueOf(x.getRank()) + " " + x.getPoints() + "\n");
        }*/
        List<PointRule> gameDeck = new ArrayList<>(pulledCards.subList(0, pulledCards.size() - 4));// Used Deck (48 cards)
            pulledCards.subList(0, pulledCards.size() - 4).clear();
       /*for(PointRule p : Board){
            System.out.println(String.valueOf(p.getSuit()) + String.valueOf(p.getRank()) + " " + p.getPoints() + "\n");
        }*/
        /*System.out.println("Current Deck");
        for (PointRule f : Deck) {
            System.out.println(String.valueOf(f.getSuit()) + String.valueOf(f.getRank()) + " " + f.getPoints() + "\n");
        }
        System.out.println("After pRules");
            for (PointRule p : pointRules) {
                System.out.println(String.valueOf(p.getSuit()) + String.valueOf(p.getRank()) + " " + p.getPoints() + "\n");
            }*/

        //IMPORTANT!!!!!!!!!
        /*System.out.println("Test");
        PointRule.dealHand(Deck,PDeck);
        for(PointRule p : PDeck) {
            System.out.println(String.valueOf(p.getSuit()) + String.valueOf(p.getRank()) + " " + p.getPoints() + "\n");
        }*/

        /*EzBot Bot1 = new EzBot();
        PointRule.dealHand(gameDeck,Bot1.getBot1Deck());
        Bot1.Move(Board,Bot1.getBot1Deck());
        System.out.println(Bot1.getTotalPoint());
        */
        /*MidBot Bot2 = new MidBot();
        PointRule.dealHand(gameDeck,Bot2.getBot2Deck());
        Bot2.Move(Board,Bot2.getBot2Deck(),null);
        System.out.println(Bot2.getTotalPoint());*/
        /*HardBot Bot3 = new HardBot();

        Player P1 = new Player();
        PointRule.dealHand(gameDeck,Bot3.getBot3Deck());
        PointRule.dealHand(gameDeck,P1.getpDeck());
        Bot3.Move(Board,Bot3.getBot3Deck(),gameDeck);
        P1.Move(Board,P1.getpDeck(),null);
        System.out.println(Bot3.getTotalPoint());
        System.out.println(P1.getTotalPoint());*/
        Game game = null;



            System.out.println("Welcome to the Misti Game!");
            int numPlayers = 0;
            boolean validInput = false;

            System.out.println("Choose number of the players by pressing 2,3 or 4");
            while (!validInput) {
                try {
                    System.out.println("Please enter a number: ");
                    numPlayers = sc.nextInt();
                    validInput = true;
                } catch (InputMismatchException e) {
                    System.out.println("Wrong input type.");
                    sc.nextLine();
                }
            }
            switch (numPlayers) {
                case 2:
                    System.out.println("You've chosen to play with 2 players.");
                    System.out.println("Choose difficulty of the bot by pressing 1 for easiest 2 for normal 3 for expert level!");
                    int twoPlayerChoice = sc.nextInt();
                    break;
                case 3:
                    System.out.println("You've chosen to play with 3 players.");
                    System.out.println("Choose difficulty of the first bot by pressing 1 for easiest 2 for normal 3 for expert level!");
                    int threePlayerChoice1 = sc.nextInt();
                    System.out.println("Choose difficulty of the second bot by pressing 1 for easiest 2 for normal 3 for expert level!");
                    int threePlayerChoice2 = sc.nextInt();
                    break;
                case 4:
                    System.out.println("You've chosen to play with 4 players.");
                    System.out.println("Choose difficulty of the first bot by pressing 1 for easiest 2 for normal 3 for expert level!");
                    int fourPlayerChoice1 = sc.nextInt();
                    System.out.println("Choose difficulty of the second bot by pressing 1 for easiest 2 for normal 3 for expert level!");
                    int fourPlayerChoice2 = sc.nextInt();
                    System.out.println("Choose difficulty of the third bot by pressing 1 for easiest 2 for normal 3 for expert level!");
                    int fourPlayerChoice3 = sc.nextInt();
                    break;
                default:
                    System.out.println("Invalid number of players. Please choose a number between 2 and 4.");
                    break;
            }


        }
 

    }