import java.util.ArrayList;
import java.util.List;
import java.util.Random;

 public class EzBot extends Player {
     @Override
    public void Move(List<PointRule> board,List<PointRule> deck, List<PointRule> gameDeck){

        Random random = new Random();
        int index = random.nextInt(0,(deck.size()-1));
        PointRule card = deck.get(index);

        if(board.size()==0){
            board.add(card);
            deck.remove(card);
        }
        else if((board.size()==1 && board.get(board.size()-1).getRank() == card.getRank())) {
            PointRule.takeCardMisti(board, pMisti);
            pMisti.add(card);
            totalPoint += Calculator.calculateMisti(pMisti);
            Game.latestPlayer = this;
            deck.remove(card);
        }
        else if(board.get(board.size()-1).getRank() == card.getRank() || card.getRank()=='J'){
            PointRule.takeCardNormal(board,pNormal);
            pNormal.add(card);
            totalPoint += Calculator.calculateNormal(pNormal);
            Game.latestPlayer = this;
            deck.remove(card);
        }else {
            board.add(card);
            deck.remove(card);
        }

     }
}